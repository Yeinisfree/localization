import cv2
import numpy as np
import matplotlib.pyplot as plt
import time
import os
import tracking 

__db_imgs_list_name = []
__db_imgs_list = []
__db_imgs = []
__num_db_imgs = 0

__DBs_pose = []
__cur_loc_db = [0, 0]
__cur_loc_q = [0, 0]
__DB_idx_list = []

__section1 = 7
__scale_x = 6.5
__scale_y = 11

__range_x = 3.5 * __scale_x
__range_y = 2.5 * __scale_y

__ax = 1

def save_DBs_pose(db_path):
    __db_imgs_list_name = os.listdir(db_path)
    __db_imgs_list_name = sorted(__db_imgs_list_name)
    
    __num_db_imgs = len(__db_imgs_list_name)
    
    # save db imgs
    for i in range(0, __num_db_imgs):
        img = cv2.imread(db_path + __db_imgs_list_name[i])
        # img = cv2.resize(img, ())
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        __db_imgs_list.append(img)  
    
    # section & db pose
    for i in range(0, __section1):
        __DBs_pose.append([0, i * __scale_y])
        
        section1_x = 0
        section1_y = i * __scale_y

    for i in range(__section1, __num_db_imgs):
        __DBs_pose.append([section1_x * __scale_x, section1_y])
        section1_x += 1
    
    
    # plt.figure(1)
    # for i in range(0, __num_db_imgs):
    #     plt.scatter(__DBs_pose[i][0], __DBs_pose[i][1], 90)
    # plt.show()
    
    return __db_imgs_list, __db_imgs_list_name, __num_db_imgs, __DBs_pose

def Quantization(tracking_pose, __DBs_pose, __num_db_imgs, __range_x, __range_y, __ax):
     
    # search range setting
    x_range_left = tracking_pose[0] - __range_x
    x_range_right = tracking_pose[0] + __range_x
    y_range_bottom = tracking_pose[1] - __range_y
    y_range_top =  tracking_pose[1] + __range_y
    
    # search DBs within range
    min_diff = 100.0
    DB_idx_list = []
    cur_loc_db = []
    cur_loc_q = []
    
    ## __ax == 0 --> x-axis
    ## __ax == 1 --> y-axis
    
    for i in range(0, __num_db_imgs):
        if (x_range_left < __DBs_pose[i][0] and __DBs_pose[i][0] < x_range_right
            and y_range_bottom < __DBs_pose[i][1] and __DBs_pose[i][1] < y_range_top):
            DB_idx_list.append(i)
    
    if(__ax == 0):
        for i in DB_idx_list:
            if(abs(__DBs_pose[i][0] - tracking_pose[0]) < min_diff):
                min_diff = abs(__DBs_pose[i][0] - tracking_pose[0])
                cur_loc_db = __DBs_pose[i].copy()
                cur_loc_q = tracking_pose.copy()
                
    elif(__ax == 1):
        for i in DB_idx_list:
            if(abs(__DBs_pose[i][1] - tracking_pose[1]) < min_diff):
                min_diff = abs(__DBs_pose[i][1] - tracking_pose[1])
                cur_loc_db = __DBs_pose[i].copy()
                cur_loc_q = tracking_pose.copy()

    else:
        print("Quantization Error - Axis")

    
    __cur_loc_db = cur_loc_db
    __cur_loc_q = cur_loc_q
    __DB_idx_list = DB_idx_list
                
    return cur_loc_db, DB_idx_list

def recalib(__db_imgs_list, __DB_idx_list, __DBs_pose, img_q, cur_loc_db, dist_th, count_th, nndr = 0.7, nfeatures = 1000):
    sift = cv2.SIFT_create(nfeatures)
    bf = cv2.BFMatcher()
    num_prev_matches = 0
    min = 100000
    best_idx = 0
    count = 0
    
    img_q = cv2.cvtColor(img_q, cv2.COLOR_BGR2GRAY)
    
    print(__DB_idx_list)
    
    for i in __DB_idx_list:
        img_d = __db_imgs_list[i]
        
        ### how to check the similarity ###
        ### 1. using matching ###
        # img_d = cv2.resize(img_d, (img_q.shape[1], img_q.shape[0]))
        kp_d, des_d = sift.detectAndCompute(img_d, None)
        kp_q, des_q = sift.detectAndCompute(img_q, None)
    
        matches = bf.knnMatch(des_q, des_d, k=2)
        
        ## filtering - matched distances ##
        good_matches = []
        temp_good_matches = []
        
        for m, n in matches:
            if(m.distance < dist_th):
                if m.distance < nndr * n.distance:
                    temp_good_matches.append(m)
                    
        if(len(temp_good_matches) > count_th):
            if(len(temp_good_matches) > num_prev_matches):
                
                print("-----------------------")
                
                num_prev_matches = len(temp_good_matches)
                best_idx = i
                good_matches = temp_good_matches
                __cur_loc_db = __DBs_pose[best_idx].copy()
        
        else:
            __cur_loc_db = cur_loc_db
    
    
    return __cur_loc_db, best_idx
    
def decision_axis(cur_db_idx, __section1):
    ## __ax == 0 --> x-axis
    ## __ax == 1 --> y-axis
    
    if(cur_db_idx <= __section1):
        __ax = 1
    else:
        __ax = 0
        
    return __ax
    
    

    
db_path = "/home/cgv/0328/dataset/db_Part2/"
qpath = "/home/cgv/0328/part2_AF_0328/test"

# DB 사진 저장, 좌표 저장
db_imgs_list, db_imgs_list_name, num_db_imgs, DBs_pose = save_DBs_pose(db_path)

# Q 읽어옴

num_images = 55
images = []

for i in range(0, num_images):
    img = cv2.imread(qpath + str(i) + ".jpg")
    images.append(img)

prev_idx = 0

nfeatures = 1000
ratio = 0.8
angle_th = 30
RT_update = np.eye(4)

K = np.array([[301.39596558, 0.0, 316.70672662],
                         [0.0, 300.95941162, 251.54445701],
                         [0.0, 0.0, 1.0]])

cam_pos = [0.0, 0.0]



flags = 1

# tracking
track = tracking.Tracking()

# feature detection for first
prev_kp, prev_des = track.feature_detection(images[prev_idx], nfeatures)

plt.figure(1)

for i in range(1, num_images):
    # plt.cla()
    
    print(i)
    # feature detection & matching
    curr_kp, curr_des = track.feature_detection(images[i], nfeatures)
    
    src_pts, dst_pts = track.feature_matching(prev_kp, prev_des, curr_kp, curr_des, ratio)
    
    # remove outliers
    src_pts, dst_pts = track.remove_outliers_direction_auto(src_pts, dst_pts)
    src_pts, dst_pts = track.remove_outliers_length(src_pts, dst_pts)
    
    mean_direction_vector = track.get_mean_direction_vector()
    
    track.detect_rotation(i, angle_th)
    
    cam_pos = track.get_translation_Essential(cam_pos, src_pts, dst_pts, K, flags)
    rot_suspectation = track.get_suspectation()
    
    print(cam_pos)
    
    # if(rot_suspectation == 1):
    #     nndr = 0.9
    #     nfeatures = 750
    #     dist_th = 400
    #     count_th = 10
    # else:
    #     nndr = 0.7
    #     nfeatures = 1000
    #     dist_th = 200
    #     count_th = 40
    
    # prev_idx = i
    # prev_kp, prev_des = curr_kp, curr_des
    
    # # Normalization to DB coordinates
    # cur_loc_db, DB_idx_list = Quantization(cam_pos, DBs_pose, num_db_imgs, __range_x, __range_y, __ax)
    
    # #recalib
    # __cur_loc_db, cur_db_idx = recalib(db_imgs_list, DB_idx_list, DBs_pose, images[i], cur_loc_db, dist_th, count_th, nndr, nfeatures)
    # __ax = decision_axis(cur_db_idx, __section1)
    
    # print("before recalib: ", cur_loc_db)
    # print("after recalib: ", __cur_loc_db)
    # print()
    
    
    
    # plt.scatter(cur_loc_db[0], cur_loc_db[1], 30, "yellow", zorder = 3)
    # plt.scatter(__cur_loc_db[0], __cur_loc_db[1], 80, "red", zorder = 4)
    plt.scatter(cam_pos[0], cam_pos[1], 20, "gray", zorder = 2)
    # for i in range(0, num_db_imgs):
    #     plt.scatter(DBs_pose[i][0], DBs_pose[i][1], 120, "blue", zorder = 1)
    #     plt.annotate(i, xy = (DBs_pose[i][0], DBs_pose[i][1]))
    
    # plt.legend(("only Quan. (adj. x)", "Quan. + adj.", "qqmatching -> pose", "DB"), loc = "lower right")
    
    # plt.pause(0.1)
    # # plt.close()
    
    # # real estimated pose <-- after recalib
    # cam_pos = __cur_loc_db.copy()
    
plt.show()